USE rep;

TRUNCATE TABLE crep_code;

LOAD DATA LOCAL INFILE 'D:/UpdateDatabase/FilesCSV/ETL_CC.CSV'
INTO TABLE crep_code
COLUMNS TERMINATED BY ';'
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
	@Repair_Code ,
	@Description,
	@No_Amount,
	@Guarantee,
	@Parts_Only,
	@Parts_Manpower,
	@Total,
	@Default_Mode,
	@Quantity,
	@Account_Cost,
	@Account_Revenue,
	@Account_Month,
	@Rebill_Type,
	@Rebill_Vat_Code,
	@Account_Invest,
	@Relief,
	@Autorebill ,
	@`Linked-KM` ,
	@Rep_Type,
	@Tire_Type,
	@Factory_Owner,
	@Filler_2,
	@Family_Code,
	@Date_Last_Update,
	@User_Last_Update,
	@CC_Crep_Code_Status,
	@Group_description
)
SET
	Repair_Code = IF(@Repair_Code = '', NULL, CAST(@Repair_Code AS SIGNED)),
	Description = IF(@Description = '', NULL, @Description),
	No_Amount = IF(@No_Amount = '', NULL, @No_Amount),
	Guarantee = IF(@Guarantee = '', NULL, @Guarantee),
	Parts_Only = IF(@Parts_Only = '', NULL, @Parts_Only),
	Parts_Manpower = IF(@Parts_Manpower = '', NULL, @Parts_Manpower),
	Total = IF(@Total = '', NULL, @Total),
	Default_Mode = IF(@Default_Mode = '', NULL, @Default_Mode),
	Quantity = IF(@Quantity = '', NULL, @Quantity),
	Account_Cost = IF(@Account_Cost = '', NULL, @Account_Cost),
	Account_Revenue = IF(@Account_Revenue = '', NULL, @Account_Revenue),
	Account_Month = IF(@Account_Month = '', NULL, @Account_Month),
	Rebill_Type = IF(@Rebill_Type = '', NULL, @Rebill_Type),
	Rebill_Vat_Code = IF(@Rebill_Vat_Code = '', NULL, @Rebill_Vat_Code),
	Account_Invest = IF(@Account_Invest = '', NULL, @Account_Invest),
	Relief = IF(@Relief = '', NULL, @Relief),
	Autorebill = IF(@Autorebill = '', NULL, @Autorebill),
	`Linked-KM` = IF(@`Linked-KM` = '', NULL, @`Linked-KM`),
	Rep_Type = IF(@Rep_Type = '', NULL, @Rep_Type),
	Tire_Type = IF(@Tire_Type = '', NULL, @Tire_Type),
	Factory_Owner = IF(@Factory_Owner = '', NULL, @Factory_Owner),
	Filler_2 = IF(@Filler_2 = '', NULL, @Filler_2),
	Family_Code = IF(@Family_Code = '', NULL, @Family_Code),
	Date_Last_Update = IF(@Date_Last_Update = '', NULL, @Date_Last_Update),
	User_Last_Update = IF(@User_Last_Update = '', NULL, @User_Last_Update),
	CC_Crep_Code_Status = IF(@CC_Crep_Code_Status = '', NULL, @CC_Crep_Code_Status),
	Group_description = IF(@Group_description = '', NULL, @Group_description)
;

CALL sp_UpdateTable_etl_cc;