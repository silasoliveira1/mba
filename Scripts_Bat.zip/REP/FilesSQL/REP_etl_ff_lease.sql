USE rep;

TRUNCATE TABLE etl_ff_lease;

LOAD DATA LOCAL INFILE 'D:/UpdateDatabase/FilesCSV/ETL_FF_LEASE.CSV'
INTO TABLE etl_ff_lease
COLUMNS TERMINATED BY ';'
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
	@customer_num,
	@invoice_num,
	@month_invoicing,
	@ctrv_num,
	@lease_value,
	@invoice_type,
	@season_invoice,
	@due_date
)
SET
	customer_num = IF(@customer_num = '', NULL, CAST(@customer_num AS SIGNED)),
	invoice_num = IF(@invoice_num = '', NULL, CAST(@invoice_num AS SIGNED)),
	month_invoicing = IF(@month_invoicing = '', NULL, @month_invoicing),
	ctrv_num = IF(@ctrv_num = '', NULL, CAST(@ctrv_num AS SIGNED)),
	lease_value = IF(@lease_value = '', NULL, @lease_value),
	invoice_type = IF(@invoice_type = '', NULL, @invoice_type),
	season_invoice = IF(@season_invoice = '', NULL, @season_invoice),
	due_date = IF(@due_date = '', NULL, STR_TO_DATE(@due_date, '%d/%m/%Y'))
;