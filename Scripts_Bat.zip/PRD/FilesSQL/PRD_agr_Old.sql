USE ald_dwh_repl;

TRUNCATE TABLE agr;

LOAD DATA LOCAL INFILE 'D:/UpdateDatabase/FilesCSV/AGR.CSV'
INTO TABLE agr
CHARACTER SET 'latin1'
COLUMNS TERMINATED BY ';'
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
	@`Invoice Number`,
	@`Repair Agrmt`,
	@`Date`,
	@`KM`,
	@`Invoice Num`,
	@`Type`,
	@`Total`,
	@`Customer Num`,
	@`Plate`,
	@`Vehicle Nr`,
	@`CTRV Nr`,
	@`Supplier`,
	@`Supplier Name`,
	@`Parts`,
	@`Man Power`,
	@`PMI Invoice Date`,
	@`Reference`,
	@`FieldConcat1`,
	@`FieldConcat2`,
	@`FieldConcat3`,
	@`FieldConcat4`,
	@`FieldConcat5`,
	@`FieldConcat6`,
	@`FieldConcat7`,
	@`FieldConcat8`,
	@`Remarks`,
	@`agr_rebil`,
	@`id_prod`,
	@`id_prod_vr`,
	@`id_prod_ref`,
	@`crep_vr_sn`
)
SET
	`Invoice Number` = IF(@`Invoice Number` = '', NULL, @`Invoice Number`),
	`Repair Agrmt` = IF(@`Repair Agrmt` = '', NULL, CAST(@`Repair Agrmt` AS SIGNED)),
	`Date` = STR_TO_DATE(@`Date`, '%d/%m/%Y %H:%i:%s'),
    `KM` = IF(@`KM`= '', NULL, CAST(@`KM` AS SIGNED)),
	`Invoice Num` = IF(@`Invoice Num` = '', NULL, CAST(@`Invoice Num` AS SIGNED)),
	`Type` = IF(@`Type` = '', NULL, @`Type`),
    `Total` = IF(@`Total` = '', NULL, @`Total`),
    `Customer Num` = IF(@`Customer Num` = '', NULL, @`Customer Num`),
    `Plate` = IF(@`Plate` = '', NULL, @`Plate`),
    `Vehicle Nr` = IF(@`Vehicle Nr` = '', NULL, CAST(@`Vehicle Nr` AS SIGNED)),
	`CTRV Nr` = IF(@`CTRV Nr` = '', NULL, CAST(@`CTRV Nr` AS SIGNED)),
    `Supplier` = IF(@`Supplier` = '', NULL, CAST(@`Supplier` AS SIGNED)),
    `Supplier Name` = IF(@`Supplier Name` = '', NULL, @`Supplier Name`),
    `Parts` = IF(@`Parts` = '', NULL, CAST(@`Parts` AS SIGNED)),
    `Man Power` = IF(@`Man Power` = '', NULL, CAST(@`Man Power` AS SIGNED)),
    `PMI Invoice Date` = IF(@`PMI Invoice Date` = '', NULL, CAST(@`PMI Invoice Date` AS SIGNED)),
    `Reference` = IF(@`Reference` = '', NULL, @`Reference`),
    `FieldConcat1` = IF(@`FieldConcat1` = '', NULL, @`FieldConcat1`),
    `FieldConcat2` = IF(@`FieldConcat2` = '', NULL, @`FieldConcat2`),
    `FieldConcat3` = IF(@`FieldConcat3` = '', NULL, @`FieldConcat3`),
    `FieldConcat4` = IF(@`FieldConcat4` = '', NULL, @`FieldConcat4`),
    `FieldConcat5` = IF(@`FieldConcat5` = '', NULL, @`FieldConcat5`),
    `FieldConcat6` = IF(@`FieldConcat6` = '', NULL, @`FieldConcat6`),
    `FieldConcat7` = IF(@`FieldConcat7` = '', NULL, @`FieldConcat7`),
    `FieldConcat8` = IF(@`FieldConcat8` = '', NULL, @`FieldConcat8`),
    `Remarks` = IF(REPLACE(REPLACE(@`Remarks`, CHAR(13), ''), CHAR(10), '') = '', NULL, @`Remarks`),
    `agr_rebil` = NULL,
    `id_prod` = NULL,
    `id_prod_vr` = NULL,
    `id_prod_ref` = NULL,
    `crep_vr_sn` = NULL
;

CALL sp_UpdateTable_agr;