USE controle_nf;
GO
CALL controle_nf.auto_detele_erro_imput_CP_SOL_PRDTL;
GO
CALL controle_nf.sp_insert_pmi_number_incremental;
GO
CALL controle_nf.sp_update_invoice_number_controle_nf;
GO
CALL controle_nf.sp_update_invoice_number_controle_vr;
GO
CALL controle_nf.sp_update_invoice_number_produtivo_detalhe;
GO
CALL controle_nf.sp_update_id_visual_produtivo_detalhe;
GO
CALL controle_nf.sp_update_id_visual_car_purchase;