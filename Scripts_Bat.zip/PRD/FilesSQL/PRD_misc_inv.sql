USE ald_dwh_repl;

TRUNCATE TABLE misc_inv;

LOAD DATA LOCAL INFILE 'D:/UpdateDatabase/FilesCSV/MISC_INV.CSV'
INTO TABLE misc_inv
COLUMNS TERMINATED BY ';'
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
	@`Agreement number`,
	@`PMI Number`,
	@`Invoice Type`,
	@Ctrv_number,
	@`Customer code`,
	@`Due date`,
	@`Invoice Number`,
	@`Invoice Date`,
	@`Total Value`,
	@`Detail Value`,
	@Description,
	@`Rebill Number`,
	@`Line Number`
)
SET
	`Agreement number` = IF(@`Agreement number` = '', NULL, CAST(@`Agreement number` AS SIGNED)),
	`PMI Number` = IF(@`PMI Number` = '', NULL, CAST(@`PMI Number` AS SIGNED)),
	`Invoice Type` = IF(@`Invoice Type` = '', NULL, @`Invoice Type`),
	Ctrv_number = IF(@Ctrv_number = '', NULL, CAST(@Ctrv_number AS SIGNED)),
	`Customer code` = IF(@`Customer code` = '', NULL, CAST(@`Customer code` AS SIGNED)),
	`Due date` = IF(@`Due date` = '', NULL, @`Due date`),
	`Invoice Number` = IF(@`Invoice Number` = '', NULL, CAST(@`Invoice Number` AS SIGNED)),
	`Invoice Date` = IF(@`Invoice Date` = '', NULL, @`Invoice Date`),
	`Total Value` = IF(@`Total Value` = '', NULL, @`Total Value`),
	`Detail Value` = IF(@`Detail Value` = '', NULL, @`Detail Value`),
	Description = IF(@Description = '', NULL, @Description),
	`Rebill Number` = IF(@`Rebill Number` = '', NULL, CAST(@`Rebill Number` AS SIGNED)),
	`Line Number` = IF(@`Line Number` = '', NULL, @`Line Number`)
;