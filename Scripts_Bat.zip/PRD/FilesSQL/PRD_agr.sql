-- seleciona o banco de dados a ser utilizado
USE ald_dwh_repl;

-- limpa a tabela para receber novos dados
TRUNCATE TABLE agr;

-- executa o scritp para carregar os novos dados na tabela
LOAD DATA INFILE 'D:/PRD/DADOS/Uploads/AGR.CSV'
INTO TABLE agr
CHARACTER SET 'latin1'
COLUMNS TERMINATED BY ';'
LINES TERMINATED BY '\n'
(
	@`Invoice Number`,
	@`Repair Agrmt`,
	@`Date`,
	@`KM`,
	@`Invoice Num`,
	@`Type`,
	@`Total`,
	@`Customer Num`,
	@`Plate`,
	@`Vehicle Nr`,
	@`CTRV Nr`,
	@`Supplier`,
	@`Supplier Name`,
	@`Parts`,
	@`Man Power`,
	@`PMI Invoice Date`,
	@`Reference`,
	@`FieldConcat1`,
	@`FieldConcat2`,
	@`FieldConcat3`,
	@`FieldConcat4`,
	@`FieldConcat5`,
	@`FieldConcat6`,
	@`FieldConcat7`,
	@`FieldConcat8`,
	@`Remarks`,
	@`agr_rebil`,
	@`id_prod`,
	@`id_prod_vr`,
	@`id_prod_ref`,
	@`crep_vr_sn`
)
SET
	`Invoice Number` = IF(@`Invoice Number` = '', NULL, @`Invoice Number`),
	`Repair Agrmt` = IF(@`Repair Agrmt` = '', NULL, CAST(@`Repair Agrmt` AS SIGNED)),
	`Date` = STR_TO_DATE(@`Date`, '%d/%m/%Y %H:%i:%s'),
    `KM` = IF(@`KM`= '', NULL, CAST(@`KM` AS SIGNED)),
	`Invoice Num` = IF(@`Invoice Num` = '', NULL, CAST(@`Invoice Num` AS SIGNED)),
	`Type` = IF(@`Type` = '', NULL, @`Type`),
    `Total` = IF(@`Total` = '', NULL, @`Total`),
    `Customer Num` = IF(@`Customer Num` = '', NULL, @`Customer Num`),
    `Plate` = IF(@`Plate` = '', NULL, @`Plate`),
    `Vehicle Nr` = IF(@`Vehicle Nr` = '', NULL, CAST(@`Vehicle Nr` AS SIGNED)),
	`CTRV Nr` = IF(@`CTRV Nr` = '', NULL, CAST(@`CTRV Nr` AS SIGNED)),
    `Supplier` = IF(@`Supplier` = '', NULL, CAST(@`Supplier` AS SIGNED)),
    `Supplier Name` = IF(@`Supplier Name` = '', NULL, @`Supplier Name`),
    `Parts` = IF(@`Parts` = '', NULL, CAST(@`Parts` AS SIGNED)),
    `Man Power` = IF(@`Man Power` = '', NULL, CAST(@`Man Power` AS SIGNED)),
    `PMI Invoice Date` = IF(@`PMI Invoice Date` = '', NULL, CAST(@`PMI Invoice Date` AS SIGNED)),
    `Reference` = IF(@`Reference` = '', NULL, @`Reference`),
    `FieldConcat1` = IF(@`FieldConcat1` = '', NULL, @`FieldConcat1`),
    `FieldConcat2` = IF(@`FieldConcat2` = '', NULL, @`FieldConcat2`),
    `FieldConcat3` = IF(@`FieldConcat3` = '', NULL, @`FieldConcat3`),
    `FieldConcat4` = IF(@`FieldConcat4` = '', NULL, @`FieldConcat4`),
    `FieldConcat5` = IF(@`FieldConcat5` = '', NULL, @`FieldConcat5`),
    `FieldConcat6` = IF(@`FieldConcat6` = '', NULL, @`FieldConcat6`),
    `FieldConcat7` = IF(@`FieldConcat7` = '', NULL, @`FieldConcat7`),
    `FieldConcat8` = IF(@`FieldConcat8` = '', NULL, @`FieldConcat8`),
    `Remarks` = IF(REPLACE(REPLACE(@`Remarks`, CHAR(13), ''), CHAR(10), '') = '', NULL, @`Remarks`),
    `agr_rebil` = IF(@`agr_rebil` = '', NULL, CAST(@`agr_rebil` AS SIGNED)),
    `id_prod` = IF(@`id_prod` = '', NULL, CAST(@`id_prod` AS SIGNED)),
    `id_prod_vr` = IF(@`id_prod_vr` = '', NULL, @`id_prod_vr`),
    `id_prod_ref` = IF(@`id_prod_ref` = '', NULL, @`id_prod_ref`),
    `crep_vr_sn` = IF(@`crep_vr_sn` = '', NULL, @`crep_vr_sn`)
;

-- seleciona o banco de dados a ser utilizado
USE controle_nf;

-- Executa procedures para atualizar informações na tabela controle_nf
CALL auto_detele_erro_imput_CP_SOL_PRDTL;
CALL sp_insert_pmi_number_incremental;
CALL sp_update_invoice_number_controle_nf;
CALL sp_update_invoice_number_controle_vr;
CALL sp_update_invoice_number_produtivo_detalhe;
CALL sp_update_id_visual_produtivo_detalhe;
CALL sp_update_id_visual_car_purchase;