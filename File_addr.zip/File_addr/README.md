# Class of [ Big Data Architecture ] 
## MBA in Big Data & Bussiness Analytics - Impacta Tecnologia

### Arquivo para Enriquecimento da base de dados

O arquivo dept_address.csv é utilizado na Aula 2
Os alunos devem baixar o arquivo diretamente na máquina virtual que possui o ambiente Hadoop


Testando o git com os alunos

Example de Markdown pelo shell:

<code>
#!/binh/bash
echo "lalal";  
</code>



